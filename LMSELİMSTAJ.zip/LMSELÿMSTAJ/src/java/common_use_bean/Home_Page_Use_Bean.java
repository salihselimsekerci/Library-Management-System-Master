package common_use_bean;

public class Home_Page_Use_Bean {
	private int book_count;
	private int student_count;
	private int total_issues_today;
	
	private int total_books_out;

	public int getBook_count() {
		return book_count;
	}

	public void setBook_count(int book_count) {
		this.book_count = book_count;
	}

	public int getStudent_count() {
		return student_count;
	}

	public void setStudent_count(int student_count) {
		this.student_count = student_count;
	}

	public int getTotal_issues_today() {
		return total_issues_today;
	}

	public void setTotal_issues_today(int total_issues_today) {
		this.total_issues_today = total_issues_today;
	}

	public int getTotal_books_out() {
		return total_books_out;
	}

	public void setTotal_books_out(int total_books_out) {
		this.total_books_out = total_books_out;
	}
		
		
		
}
