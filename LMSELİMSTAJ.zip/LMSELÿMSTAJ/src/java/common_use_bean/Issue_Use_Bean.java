package common_use_bean;

public class Issue_Use_Bean {
	
	
	private String description;
	private String serial_sl_no;
	private String issue_sl_no;
	private String student_id;
	private String admission_no;
	private String student_name;
	private String book_title;
	private String book_sl_no;
	private String barcode ;
	private String issue_date;
	private String renew_date1;
	private String renew_date2;
	private String renew_date3;
	private String renew_date4;
	private String renew_date5;
	private String return_date;
	private String returned_date;
	private String status;
	public String getIssue_sl_no() {
		return issue_sl_no;
	}
	public void setIssue_sl_no(String issue_sl_no) {
		this.issue_sl_no = issue_sl_no;
	}
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAdmission_no() {
		return admission_no;
	}
	public void setAdmission_no(String admission_no) {
		this.admission_no = admission_no;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public String getBook_title() {
		return book_title;
	}
	public void setBook_title(String book_title) {
		this.book_title = book_title;
	}
	public String getBook_sl_no() {
		return book_sl_no;
	}
	public void setBook_sl_no(String book_sl_no) {
		this.book_sl_no = book_sl_no;
	}
	public String getBarcode() {
		return barcode;
	}
	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}
	public String getIssue_date() {
		return issue_date;
	}
	public void setIssue_date(String issue_date) {
		this.issue_date = issue_date;
	}
	public String getReturn_date() {
		return return_date;
	}
	public void setReturn_date(String return_date) {
		this.return_date = return_date;
	}
	public String getReturned_date() {
		return returned_date;
	}
	public void setReturned_date(String returned_date) {
		this.returned_date = returned_date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSerial_sl_no() {
		return serial_sl_no;
	}
	public void setSerial_sl_no(String serial_sl_no) {
		this.serial_sl_no = serial_sl_no;
	}
	public String getRenew_date1() {
		return renew_date1;
	}
	public void setRenew_date1(String renew_date1) {
		this.renew_date1 = renew_date1;
	}
	public String getRenew_date2() {
		return renew_date2;
	}
	public void setRenew_date2(String renew_date2) {
		this.renew_date2 = renew_date2;
	}
	public String getRenew_date3() {
		return renew_date3;
	}
	public void setRenew_date3(String renew_date3) {
		this.renew_date3 = renew_date3;
	}
	public String getRenew_date4() {
		return renew_date4;
	}
	public void setRenew_date4(String renew_date4) {
		this.renew_date4 = renew_date4;
	}
	public String getRenew_date5() {
		return renew_date5;
	}
	public void setRenew_date5(String renew_date5) {
		this.renew_date5 = renew_date5;
	}
	
	
	
	
	
	
}
